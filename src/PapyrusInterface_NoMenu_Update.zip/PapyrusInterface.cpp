#include "PCH.h"
#include <SKSE/API.h>
#include <SKSE/Events.h>
#include "PapyrusInterface.h"
#include "ScreenCapture.h"
#include "logger.h"
#include "stringutils.h"

namespace PrintScreenPapyrus {

// Global state variables - THREAD SAFE with race condition fix
std::atomic<bool> g_isStarting(false);
std::atomic<bool> g_isRunning(false);
std::atomic<bool> g_cancelFlag(false);
std::atomic<bool> g_resultReady(false);
std::atomic<bool> g_initialized(false);
std::mutex g_resultMutex;
std::string g_result("Ready");

// RACE CONDITION FIX: Add global operation flag to prevent double calls
std::atomic<bool> g_operationInProgress(false);

// === Event-driven completion dispatch ===
// We dispatch a ModCallback event on the game thread when the worker finishes,
// so Papyrus doesn't need to poll. Papyrus side should RegisterForModEvent
// ("PrintScreenComplete", ...) to receive this.
namespace
{
    void QueueCompletionEvent(const std::string& payload)
    {
        try {
            auto* task = SKSE::GetTaskInterface();
            if (!task) {
                logger::warn("SKSE TaskInterface unavailable - cannot dispatch completion event");
                return;
            }

            // Copy payload into the task closure to avoid lifetime issues
            task->AddTask([payload]() {
                // Use the correct CommonLibSSE-NG API
                auto* eventSource = SKSE::GetModCallbackEventSource();
                if (!eventSource) {
                    logger::warn("ModCallbackEventSource unavailable - cannot dispatch completion event");
                    return;
                }

                logger::info("Dispatching PrintScreenComplete event with payload: {}", payload);
                
                SKSE::ModCallbackEvent ev{
                    RE::BSFixedString("PrintScreenComplete"),
                    RE::BSFixedString(payload),
                    0.0f,
                    nullptr
                };
                eventSource->SendEvent(&ev);
                
                logger::info("PrintScreenComplete event dispatched successfully");
            });
        } catch (const std::exception& e) {
            logger::error("QueueCompletionEvent exception: {}", e.what());
        } catch (...) {
            logger::error("QueueCompletionEvent unknown exception");
        }
    }
}

// Forward declarations
void CaptureWorkerThread(
    std::string basePath,
    std::string imageType,
    float jpgCompression,
    std::string compressionMode,
    float Duration,
    float gifFPS,
    int gifLoopCount,
    int gifCompression,
    int optimize
);

std::string PerformImageCapture(const std::string& basePath, const std::string& imageType,
                               float jpgCompression, const std::string& compressionMode);
std::string PerformGifCapture(const std::string& basePath, const std::string& imageType,
                             float jpgCompression, const std::string& compressionMode, float gifDuration,
                             float gifFPS, int gifLoopCount, int gifCompression, int optimize);
std::string PerformAPNGCapture(const std::string& basePath, const std::string& imageType,
                               float apngFPS, float apngDuration, int apngLoopCount, 
                               int apngCompression, int optimize);
std::string ToLowerCase(const std::string& str);
std::string GenerateTimestampedFilename(const std::string& basePath, const std::string& extension);

void InitializeState() {
    g_isStarting.store(false);
    g_isRunning.store(false);
    g_cancelFlag.store(false);
    g_resultReady.store(false);
    g_operationInProgress.store(false);
    
    {
        std::lock_guard<std::mutex> lock(g_resultMutex);
        g_result = "Ready";
    }
    
    g_initialized.store(true);
    logger::info("PrintScreen Papyrus state initialized");
}

// Path validation - only used by Papyrus CheckPath function
bool IsValidPath(const std::string& pathStr) {
    if (pathStr.empty()) return false;
    
    // Basic path validation - check if it looks like a Windows path
    if (pathStr.length() < 3) return false;
    
    // Check for drive letter format (C:\ or C:/) or UNC path (\\)
    if (!((pathStr[1] == ':' && (pathStr[2] == '\\' || pathStr[2] == '/')) || 
          (pathStr[0] == '\\' && pathStr[1] == '\\'))) {
        logger::debug("Path format validation failed: {}", pathStr);
        return false;
    }
    
    logger::debug("Path format validation passed, testing filesystem access: {}", pathStr);
    
    try {
        std::filesystem::path fsPath(pathStr);
        
        std::error_code ec;
        bool pathExists = std::filesystem::exists(fsPath, ec);
        
        if (ec) {
            logger::debug("Error checking path existence: {} ({})", ec.message(), pathStr);
            return false;
        }
        
        if (!pathExists) {
            logger::debug("Path doesn't exist, attempting to create: {}", pathStr);
            bool created = std::filesystem::create_directories(fsPath, ec);
            
            if (ec || !created) {
                logger::debug("Failed to create directory: {} ({})", ec.message(), pathStr);
                return false;
            }
            
            logger::debug("Successfully created directory: {}", pathStr);
        }
        
        // Test write access by creating a temporary file
        std::filesystem::path testFile = fsPath / "printscreen_test_write.tmp";
        
        std::ofstream testStream(testFile, std::ios::binary);
        if (!testStream.is_open()) {
            logger::debug("Failed to open test file for writing: {}", testFile.string());
            return false;
        }
        
        testStream.write("test", 4);
        testStream.close();
        
        if (testStream.fail()) {
            logger::debug("Failed to write to test file: {}", testFile.string());
            std::filesystem::remove(testFile, ec);
            return false;
        }
        
        // Test read access
        std::ifstream readStream(testFile, std::ios::binary);
        if (!readStream.is_open()) {
            logger::debug("Failed to open test file for reading: {}", testFile.string());
            std::filesystem::remove(testFile, ec);
            return false;
        }
        
        char buffer[4];
        readStream.read(buffer, 4);
        readStream.close();
        
        if (readStream.fail() || std::string(buffer, 4) != "test") {
            logger::debug("Failed to read from test file: {}", testFile.string());
            std::filesystem::remove(testFile, ec);
            return false;
        }
        
        // Clean up the test file
        bool removed = std::filesystem::remove(testFile, ec);
        if (ec || !removed) {
            logger::warn("Failed to remove test file: {} ({})", testFile.string(), ec.message());
        }
        
        logger::debug("Path validation successful - read/write access confirmed: {}", pathStr);
        return true;
        
    } catch (const std::exception& e) {
        logger::error("Exception during path validation: {} ({})", e.what(), pathStr);
        return false;
    } catch (...) {
        logger::error("Unknown exception during path validation: {}", pathStr);
        return false;
    }
}

std::string TakePhoto(
    RE::StaticFunctionTag*,
    std::string basePath,
    std::string imageType,
    float jpgCompression,
    std::string compressionMode,
    float Duration,
    float gifFPS,
    int gifLoopCount,
    int gifCompression,
    int optimize
) {
    logger::info("=== PAPYRUS TAKEPHOTO CALLED ===");
    logger::info("Parameters: basePath='{}', imageType='{}', jpgCompression={}, Mode='{}', Duration={}",
                basePath, imageType, jpgCompression, compressionMode, Duration);
    logger::info("GIF Parameters: FPS={}, LoopCount={}, Compression={}", gifFPS, gifLoopCount, gifCompression);
    logger::info("Optimize (Delta Encoding): {}", optimize);

    // RACE CONDITION FIX: Atomic check and set - prevents double calls
    bool expected = false;
    if (!g_operationInProgress.compare_exchange_strong(expected, true)) {
        logger::warn("TakePhoto called while capture already running or starting (operationInProgress was already true)");
        return "Already running";
    }

    // Additional safety checks
    if (g_isStarting.load() || g_isRunning.load()) {
        g_operationInProgress.store(false);
        logger::warn("TakePhoto: secondary state check failed - starting={}, running={}", 
                    g_isStarting.load(), g_isRunning.load());
        return "Already running";
    }

    logger::info("Current state - running: 0, starting: 0, cancelFlag: 0, resultReady: 0, initialized: {}", 
                g_initialized.load());

    // Set starting state
    g_isStarting.store(true);
    g_cancelFlag.store(false);
    g_resultReady.store(false);

    {
        std::lock_guard<std::mutex> lock(g_resultMutex);
        g_result = "Starting";
    }

    logger::info("Starting capture thread... (starting: 1, running: 0)");

    // Start worker thread
    try {
        std::thread captureThread(CaptureWorkerThread, basePath, imageType, jpgCompression, 
                                  compressionMode, Duration, gifFPS, gifLoopCount, 
                                  gifCompression, optimize);
        captureThread.detach();
        
        logger::info("Capture thread started successfully");
        return "Started";
        
    } catch (const std::exception& e) {
        logger::error("Failed to start capture thread: {}", e.what());
        
        g_isStarting.store(false);
        g_operationInProgress.store(false);
        
        {
            std::lock_guard<std::mutex> lock(g_resultMutex);
            g_result = "Ready";
        }
        
        return "Thread start failed";
    }
}

std::string Get_Result(RE::StaticFunctionTag*) {
    std::lock_guard<std::mutex> lock(g_resultMutex);
    
    logger::debug("Get_Result called");
    logger::debug("Current state - running: {}, starting: {}, resultReady: {}, result: '{}'", 
                 g_isRunning.load(), g_isStarting.load(), g_resultReady.load(), g_result);

    // Handle completion callbacks
    if (g_resultReady.load()) {
        std::string result = g_result;
        
        if (result.find("CALLBACK_") == 0) {
            logger::info("Returning {} callback", result);
            
            // Reset state after callback
            g_result = "Ready";
            g_resultReady.store(false);
            g_operationInProgress.store(false);
            
            logger::debug("State reset to Ready after callback");
            return result;
        }
    }

    // Return current state
    if (g_isRunning.load() || g_isStarting.load()) {
        logger::debug("Capture still running");
    } else {
        logger::debug("Returning current result: {}", g_result);
    }

    return g_result;
}

std::string Cancel(RE::StaticFunctionTag*) {
    logger::info("Cancel requested");
    
    bool wasActive = g_isRunning.load() || g_isStarting.load();
    if (!wasActive) {
        logger::info("Cancel called but nothing was running");
        return "Nothing to cancel";
    }

    g_cancelFlag.store(true);
    logger::info("Cancel flag set");

    // Brief wait for thread to respond
    auto startTime = std::chrono::steady_clock::now();
    while ((g_isRunning.load() || g_isStarting.load()) && 
           std::chrono::steady_clock::now() - startTime < std::chrono::milliseconds(1000)) {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }

    if (g_isRunning.load() || g_isStarting.load()) {
        logger::warn("Thread didn't respond to cancel - forcing reset");
        ForceReset(nullptr);
        return "Force cancelled";
    }

    logger::info("Cancel completed successfully");
    return "Cancelled";
}

std::string ForceReset(RE::StaticFunctionTag*) {
    logger::info("ForceReset called - performing emergency cleanup");
    
    g_isStarting.store(false);
    g_isRunning.store(false);
    g_cancelFlag.store(false);
    g_resultReady.store(false);
    g_operationInProgress.store(false);
    
    {
        std::lock_guard<std::mutex> lock(g_resultMutex);
        g_result = "Ready";
    }
    
    logger::info("Force reset completed");
    return "Reset complete";
}

std::string ResetState(RE::StaticFunctionTag*) {
    logger::info("ResetState called - performing clean initialization");
    
    if (!g_isRunning.load() && !g_isStarting.load()) {
        InitializeState();
        logger::info("PrintScreen state initialized to clean state");
        return "State reset to clean";
    } else {
        logger::info("ResetState called while operation active - ignoring");
        return "Cannot reset while active";
    }
}

bool CheckPath(RE::StaticFunctionTag*, std::string path) {
    logger::debug("CheckPath called with path: '{}'", path);
    
    bool isValid = IsValidPath(path);
    
    if (isValid) {
        logger::info("Path validation successful: {}", path);
    } else {
        logger::error("Path validation failed: {}", path);
    }
    
    return isValid;
}

void CaptureWorkerThread(
    std::string basePath,
    std::string imageType,
    float jpgCompression,
    std::string compressionMode,
    float Duration,
    float gifFPS,
    int gifLoopCount,
    int gifCompression,
    int optimize
) {
    logger::info("=== CAPTURE WORKER THREAD STARTED ===");
    logger::info("Parameters: basePath='{}', imageType='{}', jpgCompression={}, compressionMode='{}', Duration={}",
                basePath, imageType, jpgCompression, compressionMode, Duration);
    logger::info("GIF Parameters: FPS={}, LoopCount={}, Compression={}", gifFPS, gifLoopCount, gifCompression);
    logger::info("Optimize (Delta Encoding): {}", optimize);

    // Transition from starting to running
    g_isStarting.store(false);
    g_isRunning.store(true);
    
    {
        std::lock_guard<std::mutex> lock(g_resultMutex);
        g_result = "Running";
    }

    std::string completionResult;
    
    try {
        if (g_cancelFlag.load()) {
            completionResult = "CALLBACK_CANCELLED";
            logger::info("=== CAPTURE WORKER THREAD COMPLETED: Cancelled (early) ===");
        } else {
            // Perform the actual capture based on image type
            std::string normalizedImageType = ToLowerCase(imageType);

            // Check for animated GIF variants
            bool isAnimatedGif = (normalizedImageType == "gif_multiframe" ||
                                  normalizedImageType == "agif" ||
                                  normalizedImageType == "animated_gif" ||
                                  normalizedImageType == "animatedgif" ||
                                  normalizedImageType == "gif_animated" ||
                                  normalizedImageType == "gifanim");

            // Check for APNG variants
            bool isAnimatedPng = (normalizedImageType == "apng" ||
                                  normalizedImageType == "animated_png" ||
                                  normalizedImageType == "png_animated" ||
                                  normalizedImageType == "animatedpng" ||
                                  normalizedImageType == "apng_multiframe");

            if (isAnimatedGif) {
                logger::info("Detected animated GIF request (imageType: '{}')", imageType);
                completionResult = PerformGifCapture(basePath, normalizedImageType, jpgCompression, 
                                                     compressionMode, Duration, gifFPS, gifLoopCount, 
                                                     gifCompression, optimize);
            } else if (isAnimatedPng) {
                logger::info("Detected animated PNG (APNG) request (imageType: '{}')", imageType);
                completionResult = PerformAPNGCapture(basePath, normalizedImageType, gifFPS, Duration, 
                                                      gifLoopCount, gifCompression, optimize);
            } else {
                completionResult = PerformImageCapture(basePath, normalizedImageType, jpgCompression, 
                                                       compressionMode);
            }
        }
        
    } catch (const std::exception& e) {
        logger::error("Capture worker exception: {}", e.what());
        completionResult = "CALLBACK_ERROR: " + std::string(e.what());
    } catch (...) {
        logger::error("Unknown exception in capture worker");
        completionResult = "CALLBACK_ERROR: Unknown error";
    }

    // Set completion state
    g_isRunning.store(false);
    g_cancelFlag.store(false);
    g_resultReady.store(true);
    g_operationInProgress.store(false);

    {
        std::lock_guard<std::mutex> lock(g_resultMutex);
        g_result = completionResult;
    }

    logger::info("=== CAPTURE WORKER THREAD COMPLETED: {} ===", completionResult);

    // *** CRITICAL: Dispatch completion event to Papyrus via game thread ***
    // This is the event-driven fast path - Papyrus receives immediate notification
    // without needing to poll. The polling system remains as a fallback/watchdog.
    QueueCompletionEvent(completionResult);
}

std::string PerformGifCapture(const std::string& basePath, const std::string& imageType,
                             float jpgCompression, const std::string& compressionMode, float gifDuration,
                             float gifFPS, int gifLoopCount, int gifCompression, int optimize) {
    logger::info("GIF multiframe capture settings:");
    logger::info("  Duration: {}s, FPS: {}, LoopCount: {}, Compression: {}, Optimize: {}",
                 gifDuration, gifFPS, gifLoopCount, gifCompression, optimize);
    logger::info("  Base path: {}", basePath);

    try {
        std::wstring wBasePath = util::utf8_to_wstring(basePath);

        ScreenCapture::CaptureParams params;
        params.basePath = wBasePath;
        params.format = ScreenCapture::ImageFormat::GIF;
        params.gifDuration = gifDuration;
        params.gifFPS = gifFPS;
        params.gifLoopCount = gifLoopCount;
        params.gifCompression = gifCompression;
        params.gifOptimize = optimize;
        params.cancelFlag = &g_cancelFlag;

        ScreenCapture::InitializeDirectXTexThreading();
        
        logger::info("Setting up desktop duplication for GIF capture");
        
        ScreenCapture::CaptureResult result = ScreenCapture::CaptureGIF(params);
        
        if (!result.success) {
            logger::error("GIF capture failed: {}", result.message);
            
            if (result.message.find("Cancelled") != std::string::npos || 
                result.message.find("cancelled") != std::string::npos) {
                return "CALLBACK_CANCELLED";
            }
            
            return "CALLBACK_ERROR: " + result.message;
        }
        
        std::string resultPath = util::wstring_to_utf8(result.filepath);
        
        std::error_code ec;
        auto fileSize = std::filesystem::file_size(result.filepath, ec);
        
        if (ec) {
            logger::warn("Could not get file size for: {}", resultPath);
            logger::info("GIF saved successfully: {}", resultPath);
        } else {
            logger::info("GIF saved successfully: {} ({} bytes)", resultPath, fileSize);
        }
        
        return "CALLBACK_SUCCESS";
        
    } catch (const std::exception& e) {
        logger::error("Exception during GIF capture: {}", e.what());
        return "CALLBACK_ERROR: " + std::string(e.what());
    } catch (...) {
        logger::error("Unknown exception during GIF capture");
        return "CALLBACK_ERROR: Unknown error";
    }
}

std::string PerformAPNGCapture(const std::string& basePath, const std::string& imageType,
                               float apngFPS, float apngDuration, int apngLoopCount, 
                               int apngCompression, int optimize) {
    logger::info("APNG capture settings:");
    logger::info("  Duration: {}s, FPS: {}, LoopCount: {}, Compression: {}, Optimize: {}",
                 apngDuration, apngFPS, apngLoopCount, apngCompression, optimize);
    logger::info("  Base path: {}", basePath);

    try {
        std::wstring wBasePath = util::utf8_to_wstring(basePath);

        ScreenCapture::CaptureParams params;
        params.basePath = wBasePath;
        params.format = ScreenCapture::ImageFormat::APNG;
        params.apngFPS = apngFPS;
        params.apngDuration = apngDuration;
        params.apngLoopCount = apngLoopCount;
        params.apngCompression = apngCompression;
        params.apngOptimize = optimize;
        params.cancelFlag = &g_cancelFlag;

        ScreenCapture::InitializeDirectXTexThreading();

        logger::info("Setting up desktop duplication for APNG capture");

        ScreenCapture::CaptureResult result = ScreenCapture::CaptureAPNG(params);

        if (!result.success) {
            logger::error("APNG capture failed: {}", result.message);

            if (result.message.find("Cancelled") != std::string::npos ||
                result.message.find("cancelled") != std::string::npos) {
                return "CALLBACK_CANCELLED";
            }

            return "CALLBACK_ERROR: " + result.message;
        }

        std::string resultPath = util::wstring_to_utf8(result.filepath);

        std::error_code ec;
        auto fileSize = std::filesystem::file_size(result.filepath, ec);

        if (ec) {
            logger::warn("Could not get file size for: {}", resultPath);
            logger::info("APNG saved successfully: {}", resultPath);
        } else {
            logger::info("APNG saved successfully: {} ({} bytes)", resultPath, fileSize);
        }

        return "CALLBACK_SUCCESS";

    } catch (const std::exception& e) {
        logger::error("Exception during APNG capture: {}", e.what());
        return "CALLBACK_ERROR: " + std::string(e.what());
    } catch (...) {
        logger::error("Unknown exception during APNG capture");
        return "CALLBACK_ERROR: Unknown error";
    }
}

std::string PerformImageCapture(const std::string& basePath, const std::string& imageType,
                               float jpgCompression, const std::string& compressionMode) {
    logger::info("Starting single image capture: {}", imageType);
    
    try {
        std::wstring wBasePath = util::utf8_to_wstring(basePath);
        
        ScreenCapture::CaptureParams params;
        params.basePath = wBasePath;
        params.format = ScreenCapture::StringToImageFormat(imageType);
        params.jpegQuality = jpgCompression;
        params.cancelFlag = &g_cancelFlag;
        
        if (params.format == ScreenCapture::ImageFormat::TIF) {
            params.tiffMode = ScreenCapture::StringToTiffCompression(compressionMode);
        } else if (params.format == ScreenCapture::ImageFormat::DDS) {
            params.ddsMode = ScreenCapture::StringToDDSCompression(compressionMode);
        }
        
        ScreenCapture::InitializeDirectXTexThreading();
        
        logger::info("Setting up desktop duplication");
        
        ScreenCapture::CaptureResult result = ScreenCapture::CaptureScreen(params);
        
        if (!result.success) {
            logger::error("Image capture failed: {}", result.message);
            
            if (result.message.find("Cancelled") != std::string::npos || 
                result.message.find("cancelled") != std::string::npos) {
                return "CALLBACK_CANCELLED";
            }
            
            return "CALLBACK_ERROR: " + result.message;
        }
        
        std::string resultPath = util::wstring_to_utf8(result.filepath);
        
        std::error_code ec;
        auto fileSize = std::filesystem::file_size(result.filepath, ec);
        
        if (ec) {
            logger::warn("Could not get file size for: {}", resultPath);
            logger::info("Image saved successfully: {}", resultPath);
        } else {
            logger::info("Image saved successfully: {} ({} bytes)", resultPath, fileSize);
        }
        
        return "CALLBACK_SUCCESS";
        
    } catch (const std::exception& e) {
        logger::error("Exception during image capture: {}", e.what());
        return "CALLBACK_ERROR: " + std::string(e.what());
    } catch (...) {
        logger::error("Unknown exception during image capture");
        return "CALLBACK_ERROR: Unknown error";
    }
}

std::string ToLowerCase(const std::string& str) {
    std::string lower = str;
    std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);
    return lower;
}

std::string GenerateTimestampedFilename(const std::string& basePath, const std::string& extension) {
    auto now = std::chrono::system_clock::now();
    auto time_t = std::chrono::system_clock::to_time_t(now);
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;
    
    char timestamp[64];
    std::tm* timeinfo = std::localtime(&time_t);
    std::sprintf(timestamp, "%04d%02d%02d_%02d%02d%02d_%03d",
                timeinfo->tm_year + 1900, timeinfo->tm_mon + 1, timeinfo->tm_mday,
                timeinfo->tm_hour, timeinfo->tm_min, timeinfo->tm_sec,
                static_cast<int>(ms.count()));
    
    return basePath + "\\SS_" + std::string(timestamp) + "." + extension;
}


// === UI state probe ===
// Returns true when UI/HUD is currently visible (best-effort).
// This is used by Papyrus to keep its HUD_Visable variable in sync when "tm" is toggled externally.
// NOTE: Menu-mode checks were intentionally removed. Use Utility.IsInMenuMode() on the Papyrus side instead.
bool IsUIVisible(RE::StaticFunctionTag*)
{
    auto ui = RE::UI::GetSingleton();
    if (!ui) {
        return true;  // fail-open: never assume hidden
    }

    auto menu = ui->GetMenu(RE::HUDMenu::MENU_NAME);
    if (!menu) {
        return true;
    }

    auto hud = static_cast<RE::HUDMenu*>(menu.get());
    if (!hud || !hud->uiMovie) {
        return true;
    }

    RE::GFxValue v;
    if (hud->uiMovie->GetVariable(&v, "_root._visible") && v.IsBool()) {
        return v.GetBool();
    }
    if (hud->uiMovie->GetVariable(&v, "_root._alpha") && v.IsNumber()) {
        return v.GetNumber() > 0.0;
    }

    return true;
}

bool RegisterFunctions(RE::BSScript::IVirtualMachine* vm) {
    logger::info("===============================================");
    logger::info("=== STARTING PAPYRUS FUNCTION REGISTRATION ===");
    logger::info("===============================================");
    logger::info("Virtual Machine pointer valid: 0x{:x}", reinterpret_cast<uintptr_t>(vm));

    constexpr auto scriptName = "Printscreen_Formula_script";
    logger::info("Target script name: '{}'", scriptName);

    // Initialize state
    InitializeState();

    bool allSucceeded = true;
    int successCount = 0;
    int failCount = 0;

    auto registerFunc = [&](const char* funcName, auto func) -> bool {
        logger::info("Attempting to register {}...", funcName);
        try {
            vm->RegisterFunction(funcName, scriptName, func);
            logger::info("{} registered", funcName);
            successCount++;
            return true;
        } catch (const std::exception& e) {
            logger::error("FAILED to register {}: {}", funcName, e.what());
            failCount++;
            return false;
        } catch (...) {
            logger::error("FAILED to register {}: unknown exception", funcName);
            failCount++;
            return false;
        }
    };

    allSucceeded &= registerFunc("CheckPath", CheckPath);
    allSucceeded &= registerFunc("TakePhoto", TakePhoto);
    allSucceeded &= registerFunc("Get_Result", Get_Result);
    allSucceeded &= registerFunc("Cancel", Cancel);
    allSucceeded &= registerFunc("ForceReset", ForceReset);
    allSucceeded &= registerFunc("ResetState", ResetState);


    allSucceeded &= registerFunc("IsUIVisible", IsUIVisible);
    logger::info("===============================================");
    if (allSucceeded) {
        logger::info("=== ALL {} PAPYRUS FUNCTIONS REGISTERED ===", successCount);
    } else {
        logger::error("=== PAPYRUS REGISTRATION INCOMPLETE: {} succeeded, {} failed ===", 
                     successCount, failCount);
    }
    logger::info("===============================================");

    return allSucceeded;
}

} // namespace PrintScreenPapyrus
