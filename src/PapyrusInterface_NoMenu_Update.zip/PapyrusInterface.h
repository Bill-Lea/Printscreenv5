#pragma once

#include "PCH.h"
#include <string>
#include <atomic>
#include <mutex>

namespace PrintScreenPapyrus {
    
    // Function declarations for Papyrus registration
    // UPDATED: Added 'optimize' parameter (9th parameter) for APNG delta encoding control
    std::string TakePhoto(
        RE::StaticFunctionTag*,
        std::string basePath,
        std::string imageType,
        float jpgCompression,
        std::string compressionMode,
        float gifMultiFrameDuration,
        float gifFPS,
        int gifLoopCount,
        int gifCompression,
        int optimize          // NEW: 0 = full frames, 1 = delta encoding (true differential)
    );
    
    std::string Get_Result(RE::StaticFunctionTag*);
    std::string Cancel(RE::StaticFunctionTag*);
    bool CheckPath(RE::StaticFunctionTag*, std::string path);
    std::string ForceReset(RE::StaticFunctionTag*);
    std::string ResetState(RE::StaticFunctionTag*);
    

    // UI state probe: returns true when UI/HUD is visible (best-effort)
    bool IsUIVisible(RE::StaticFunctionTag*);
    // Worker thread function
    // UPDATED: Added 'optimize' parameter
    void CaptureWorkerThread(
        std::string basePath,
        std::string imageType,
        float jpgCompression,
        std::string compressionMode,
        float gifMultiFrameDuration,
        float gifFPS,
        int gifLoopCount,
        int gifCompression,
        int optimize          // NEW: 0 = full frames, 1 = delta encoding
    );
    
    // State management functions
    void InitializeState();
    
    // Registration function
    bool RegisterFunctions(RE::BSScript::IVirtualMachine* vm);
    
    // Helper functions
    std::string ToLowerCase(const std::string& str);
    bool IsValidPath(const std::string& pathStr);
    std::string GenerateTimestampedFilename(const std::string& basePath, const std::string& extension);
    
    // Capture implementation functions
    // UPDATED: Added optimize parameter for true delta encoding control
    std::string PerformGifCapture(const std::string& basePath, const std::string& imageType,
                                 float jpgCompression, const std::string& compressionMode, float gifDuration,
                                 float gifFPS, int gifLoopCount, int gifCompression, int optimize);
    // UPDATED: Added optimize parameter for true delta encoding
    std::string PerformAPNGCapture(const std::string& basePath, const std::string& imageType,
                                   float apngFPS, float apngDuration, int apngLoopCount, 
                                   int apngCompression, int optimize);
    std::string PerformImageCapture(const std::string& basePath, const std::string& imageType,
                                   float jpgCompression, const std::string& compressionMode);
    
}
